package com.apifactory.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFactoryTechnicalExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
